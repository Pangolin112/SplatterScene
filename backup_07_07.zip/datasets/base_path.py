outputs_path = '/media/qianru/12T_Data/Experiments_output/SplatterScene/outputs/'
srn1_path = '/media/qianru/12T_Data/Data/ScanNetpp/data_1/'
SHAPENET_DATASET_ROOT = "/media/qianru/12T_Data/Data/ScanNetpp/data_1/"
save_iterations = 1
fovx = 30.0 #69.72 #42.44
fovy = 50.0